use ProjetRust::codex::save_img::save_in_img;
use ProjetRust::codex::analyzer::spectrogram;
use ProjetRust::codex::analyzer::load_file;
//use std::path::Path;
//use std::fs::File;
#[test]
fn test_main()
{
    // long wav
    //let s1 = load_file("/home/dylan.baric/afs/rust3945/img/tests/joff.wav");

    // short wav
    //let s1 = load_file("/home/dylan.baric/afs/rust3945/img/tests/WBBSE.wav");

    // image wav
    let s1 = load_file("/mnt/c/Users/THEO/ProjetRust/img/tests/Epita.wav");

    let window_size = 2048;
    let hop_size = 1024;
    //uncomment to test
    let spec = spectrogram(&s1, window_size, hop_size); 

    //---------test vec vec f32
    /*
    let mut spec = Vec::new();

    for x in 0..200 
    {
        let mut column = Vec::new();

        for y in 0..128 
        {
            let val = ((x as f32 * 0.1).sin() * (y as f32 * 0.05).cos()).abs();
            column.push(val);
        }

        spec.push(column);
    }
    */
    /*
    for i in &spec
    {
        println!("[{:?}]", i);
    }
    */

    save_in_img(spec);

    //test if img exists
    //assert!(Path::new("spectrogram.png").exists(), "YEEEEEAAAH");
}
