use projet_rust::server;

#[tokio::main]
async fn main() {
    server::run().await;
}


