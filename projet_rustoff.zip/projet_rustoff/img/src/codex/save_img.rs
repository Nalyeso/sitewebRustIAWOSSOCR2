use image::{Rgb, RgbImage};

pub fn save_in_img(all_specs: Vec<Vec<Vec<f32>>>, output_path: &str) {
    let num_tracks = all_specs.len();

    if num_tracks == 0 || all_specs[0].is_empty() || all_specs[0][0].is_empty() {
        panic!("Empty Spectrogram");
    }

    let spec_width = all_specs[0].len();
    let spec_height = all_specs[0][0].len();

    let img_width: u32 = 1600;
    let img_height: u32 = 1000;
    let track_height = img_height / num_tracks as u32;

    let mut img = RgbImage::new(img_width, img_height);
    let min_db = -70.0;

    for x in 0..img_width {
        let sx = (x as usize * spec_width / img_width as usize).min(spec_width - 1);

        for y in 0..img_height {
            let track_idx = (y / track_height) as usize;
            let rel_y = y % track_height;

            let sy = ((track_height - 1 - rel_y) as usize * spec_height / track_height as usize)
                .min(spec_height - 1);

            let val = all_specs[track_idx.min(num_tracks - 1)][sx][sy];
            let db = 20.0 * (val + 1e-9).log10();
            let normalized = ((db - min_db) / (-min_db)).clamp(0.0, 1.0);

            img.put_pixel(x, y, intensity_to_color(normalized));
        }
    }

    img.save(output_path).expect("save error");
}

fn intensity_to_color(v: f32) -> Rgb<u8> {
    if v < 0.05 {
        return Rgb([0, 0, 0]);
    }

    let r = (255.0 * v) as u8;
    let g = (150.0 * v.powi(2)) as u8;
    let b = (255.0 * (1.0 - v).powi(2)) as u8;

    Rgb([r, g, b])
}

