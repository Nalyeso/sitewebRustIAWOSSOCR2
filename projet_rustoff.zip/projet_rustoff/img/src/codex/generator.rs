use crate::codex::analyzer::{load_file, spectrogram};
use crate::codex::save_img::save_in_img;

pub fn generate_spectrogram(input_wav: &str, output_png: &str) {
    let (tracks, _sample_rate) = load_file(input_wav);

    let all_specs: Vec<Vec<Vec<f32>>> = tracks
        .iter()
        .map(|track| spectrogram(track, 2048, 512))
        .collect();

    save_in_img(all_specs, output_png);
}

