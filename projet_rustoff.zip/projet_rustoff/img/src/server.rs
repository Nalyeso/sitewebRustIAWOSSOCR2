use axum::{
    body::Body,
    extract::{DefaultBodyLimit,Multipart},
    http::{header, Response, StatusCode},
    response::IntoResponse,
    routing::post,
    Router,
};

use tower_http::cors::CorsLayer;

use crate::codex::generator::generate_spectrogram;

//start the local server
pub async fn run() {
    println!("Repo : {:?}", std::env::current_dir().unwrap());

    let app = Router::new()
        .route("/api/spectrogram", post(upload_spectrogram))
        .layer(DefaultBodyLimit::max(50*1024*1024)) //file limit to 50MB
        .layer(CorsLayer::permissive()); //Permission from the html file

    let listener = tokio::net::TcpListener::bind("127.0.0.1:3000")
        .await
        .unwrap();

    println!("Server on http://localhost:3000");

    axum::serve(listener, app).await.unwrap(); // Launch
}


//When a WAV file is send
async fn upload_spectrogram(mut multipart: Multipart) -> impl IntoResponse {
    println!("Requête reçue !");

    let input_path = "input_upload.wav";
    let output_path = "spectrogram_upload.png";

    let mut file_received = false;

    //Read part
    while let Some(field) = match multipart.next_field().await {
        Ok(field) => field,
        Err(err) => {
            eprintln!("Reading error multi : {}", err);

            return (
                StatusCode::BAD_REQUEST,
                "Reading Error",
            )
                .into_response();
        }
    } {
        let name = field.name().unwrap_or("").to_string();
        let file_name = field.file_name()
            .unwrap_or("fichier.wav").to_string();

        let data = match field.bytes().await {
            Ok(data) => data,
            Err(err) => {
                eprintln!("bytes Error : {}", err);

                return (
                    StatusCode::BAD_REQUEST,
                    "Reading Error",
                )
                    .into_response();
            }
        };

        println!("Name : {}", name);
        println!("Name of the file : {}", file_name);
        println!("Size : {}", data.len());

        if data.is_empty() {
            return (StatusCode::BAD_REQUEST, "Empty File").into_response();
        }
        //Save the file
        match tokio::fs::write(input_path, &data).await {
            Ok(_) => {
                println!("WAV saved in {}", input_path);
                file_received = true;
            }
            Err(err) => {
                eprintln!("WAV Save error : {}", err);

                return (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    "WAV save Error",
                )
                    .into_response();
            }
        }
    }

    if !file_received {
        return (StatusCode::BAD_REQUEST, "File Access Error").into_response();
    }

    println!("Spectrogram Generation...");

    generate_spectrogram(input_path, output_path);

    println!("Generated : {}", output_path);
    //Read the png file
    let image_bytes = match tokio::fs::read(output_path).await {
        Ok(bytes) => bytes,
        Err(err) => {
            eprintln!("Reading Error {} : {}", output_path, err);

            return (
                StatusCode::INTERNAL_SERVER_ERROR,
                "Generation Error",
            )
                .into_response();
        }
    };
    //Send the png to the website
    Response::builder()
        .status(StatusCode::OK)
        .header(header::CONTENT_TYPE, "image/png")
        .body(Body::from(image_bytes))
        .unwrap()
        .into_response()
}

