# Générateur de spectrogramme

Voici le site où vous pourrez retrouver toutes les informations : https://nalyeso.github.io/sitewebRustIAWOSSOCR2/index.html

Voici la page précise avec toutes les informations à propos de la génération sur site web : https://nalyeso.github.io/sitewebRustIAWOSSOCR2/spectro.html

- Après avoir télécharger le projet, unzip le fichier et aller dans le repo grâce à la console
- au niveau de img, faire "cargo run". Le serveur local se lancera
- Sur le site web, mettez votre fichier .wav et appuyer sur "générer le spectrogramme"
- Admirer le spectacle (attention il peut y avoir des dossiers en plus lorsque le serveur local s'éteint)
- N'oubliez pas de Cargo Clean à la fin
