use hound;
use rustfft::{FftPlanner, num_complex::Complex};
use std::f32::consts::PI;

pub fn load_file(path: &str) -> (Vec<Vec<f32>>, u32) {
    let reader = hound::WavReader::open(path).expect("cannot open file");
    process_reader(reader)
}
fn process_reader<R: std::io::Read>(mut reader: hound::WavReader<R>) -> (Vec<Vec<f32>>, u32) {
    let spec = reader.spec();
    let channels = spec.channels as usize;
    let samples: Vec<f32> = reader.samples::<i16>().map(|s| s.unwrap() as f32 / 32768.0).collect();
    if channels == 1 
    {
        return (vec![samples], spec.sample_rate);
    }
    let mut left = Vec::with_capacity(samples.len() / 2);
    let mut right = Vec::with_capacity(samples.len() / 2);
    let mut identical = true;
    for chunk in samples.chunks(channels) 
    {
        left.push(chunk[0]);
        if chunk.len() > 1 
        {
            right.push(chunk[1]);
            if (chunk[0] - chunk[1]).abs() > 0.001 { identical = false; }
        }
    }
    let tracks = if identical { vec![left] } else { vec![left, right] };
    (tracks, spec.sample_rate)
}
pub fn spectrogram(samples: &[f32], ws: usize, hs: usize) -> Vec<Vec<f32>> {
    let mut planner = FftPlanner::<f32>::new();
    let fft = planner.plan_fft_forward(ws);
    let window: Vec<f32> = (0..ws)
        .map(|i| 0.5 * (1.0 - (2.0 * PI * i as f32 / (ws - 1) as f32).cos()))
        .collect();        
    let mut spec = Vec::new();
    let mut pos = 0;
    while pos + ws <= samples.len() 
    {
        let mut buffer: Vec<Complex<f32>> = (0..ws)
            .map(|i| Complex { re: samples[pos + i] * window[i], im: 0.0 })
            .collect();
            
        fft.process(&mut buffer);
        let unique_bins = ws / 2;
        let mut magnitudes = Vec::with_capacity(unique_bins);
        for c in buffer.iter().take(unique_bins) 
        {
            magnitudes.push((c.re * c.re + c.im * c.im).sqrt());
        }
        spec.push(magnitudes);
        pos += hs;
    }
    spec
}
