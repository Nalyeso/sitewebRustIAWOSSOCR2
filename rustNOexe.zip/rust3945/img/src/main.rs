//use img::codex::analyzer;
mod codex;
use std::env;

fn main() 
{
    let n2: Vec<String> = env::args().collect();
    if n2.len() < 2 
    {
        println!("need ./img file");
        return;
    }
    let input_path = &n2[1];
    let (tracks, _sample_rate) = codex::analyzer::load_file(input_path);
    let mut v = Vec::new();
    for n in tracks 
    {
        v.push(codex::analyzer::spectrogram(&n, 512, 256));
    }
    codex::save_img::save_in_img(v);
    println!("Created with success, see Spectrogram.png");
}
