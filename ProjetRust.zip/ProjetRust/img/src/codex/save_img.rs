use image::{RgbImage, Rgb, ImageFormat};

pub fn save_in_img(spec: Vec<Vec<f32>>)
{
    if spec.is_empty()
    {
        panic!("spectrogram is empty");
    }
    let spec_width = spec.len();
    let spec_height = spec[0].len();
    let img_width: u32 = 820;
    let img_height: u32 = 549;
    let mut img = RgbImage::new(img_width, img_height);
    // calculating scale
    let mut max_val = 1e-9;
    for col in &spec {
        for &v in col { if v > max_val { max_val = v; } }
    }

    // threshold: 60 db
    let min_db = -60.0;

    for x in 0..img_width
    {
        for y in 0..img_height
        {
            let sx = (x as usize * spec_width) / img_width as usize;
            let sy = (y as usize * spec_height) / img_height as usize;
            let val = spec[sx][sy];
            let db = 20.0 * (val / max_val + 1e-9).log10();
            // normalisation
            let normalized = ((db - min_db) / (-min_db)).clamp(0.0, 1.0);
            let pixel = intensity_to_color(normalized);
            img.put_pixel(x, img_height - 1 - y, pixel);
        }
    }
    // saving img
    img.save_with_format("spectrogram.png", ImageFormat::Png)
        .expect("failed to save image");
}

fn intensity_to_color(v: f32) -> Rgb<u8>
{
    // weak intensity -> #000000
    if v < 0.05 
    {
        return Rgb([0, 0, 0]);
    }
    if v < 0.2 
    {
        let t = v / 0.2;
        Rgb([(80.0 * t) as u8, 0, (150.0 * t) as u8])
    } 
    else if v < 0.4
    {
        let t = (v - 0.2) / 0.2;
        Rgb([(150.0 + 105.0 * t) as u8, 0, (150.0 - 150.0 * t) as u8])
    } 
    else if v < 0.7
    {
        let t = (v - 0.4) / 0.3;
        Rgb([255, (100.0 * t) as u8, 0])
    }
    else
    {
        let t = (v - 0.7) / 0.3;
        Rgb([255, (100.0 + 155.0 * t) as u8, 0])
    }
}
