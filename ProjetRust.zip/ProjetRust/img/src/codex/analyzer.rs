use hound;
use rustfft::{FftPlanner, num_complex::Complex};
use std::f32::consts::PI;

pub fn load_file(path: &str) -> Vec<f32>
{
    let mut reader = hound::WavReader::open(path).expect("Cannot open file");
    //i16 from -1.0 to 1.0
    reader.samples::<i16>().map(|s| s.unwrap() as f32 / 32768.0).collect()
}

pub fn spectrogram(samples: &[f32], ws: usize, hs: usize) -> Vec<Vec<f32>> {
    let mut planner = FftPlanner::<f32>::new();
    let fft = planner.plan_fft_forward(ws);
    let window: Vec<f32> = (0..ws)
        .map(|i| 0.5 * (1.0 - (2.0 * PI * i as f32 / (ws-1) as f32).cos()))
        .collect();
    let mut spec = Vec::new();
    let mut pos = 0;
    while pos+ws <= samples.len()
    {
        let mut buffer: Vec<Complex<f32>> = Vec::with_capacity(ws);
        for i in 0..ws
        {
            //hamming window
            let value = samples[pos+i] * window[i];
            buffer.push(Complex { re: value, im: 0.0 });
        }

        fft.process(&mut buffer);

        //spectogram mirror bug
        let unique_bins = ws/2;
        let mut magnitudes = Vec::with_capacity(unique_bins);
        for c in buffer.iter().take(unique_bins) 
        {
            let mag = (c.re * c.re + c.im * c.im).sqrt();
            magnitudes.push(mag);
        }
        spec.push(magnitudes);
        pos += hs;
    }
    spec
}
